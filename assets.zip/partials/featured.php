<!-- FEATURED NOW 

LAST UPDATE: 2023-11-15

-->

<a href="foodquery.php" class="projItem">
    <div class="projImgCol proj_Imgcol">
        <img src="./assets/thumbnails/foodquery_thumb.jpg" alt="food query app iphone 15 pro max mockup">
    </div>
    <div class="projIntro proj_Intro">
        <h2>
            Food Query App
        </h2>
        <p>
            UI/UX
        </p>
    </div>
</a>  

<a href="work.php" class="projects-btn">
    <div class="work-icon">
    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M166.783-100.782q-44.305 0-75.153-30.848-30.848-30.848-30.848-75.153v-417.39q0-44.305 30.848-75.153 30.848-30.848 75.153-30.848h135.694v-80q0-44.305 30.849-75.154 30.848-30.848 75.153-30.848h143.042q44.305 0 75.153 30.848 30.849 30.849 30.849 75.154v80h135.694q44.305 0 75.153 30.848 30.848 30.848 30.848 75.153v417.39q0 44.305-30.848 75.153-30.848 30.848-75.153 30.848H166.783Zm0-106.001h626.434v-417.39H166.783v417.39Zm241.696-523.391h143.042v-80H408.479v80ZM166.783-206.783v-417.39 417.39Z"/></svg>
    </div>
    <div class="text-block">
        See all work
    </div>
</a>