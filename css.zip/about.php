<?php include './partials/head.php'; ?>

<div class="desktop-container">
    <?php include './partials/left-aside.php'; ?>
    <?php include './partials/about-section.php'; ?>
</div>

<div class="smallscreen-container">
    <?php include './partials/about-section.php'; ?>
</div>

<?php include './partials/mobile-nav.php'; ?>
<?php include './partials/footer.php'; ?>
