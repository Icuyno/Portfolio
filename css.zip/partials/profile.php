<div class="profile">
    <div class="logo-container">
        <a href="https://isabellecuyno.com/">
            <img src="./assets/icons/logo.svg" alt="logo and home link">
        </a>
    </div>

    <div class="main-content-container">
        <div class="main-content">

            <div class="title-container">
                <h2>Izzy Cuyno </h2>
                <h1>
                    Howdy, I’m a web designer with a pioneering spirit and I intend to create memorable interfaces and
                    experiences that delight the senses.
                </h1>
                <br>
                <h1>
                    Skillset: UI/UX design and Front-end web development
                </h1>
            </div>

        </div>
    </div>

</div>

